Dynamic Pricing + Inventory project (Q-learning version)

Files:
- retail_price_elasticity_did_phase1_phase2_qlearning.ipynb : original project notebook with Q-learning section (Section 11)
- retail_price.csv : dataset used by the notebook

Run:
1. Install dependencies if needed: pip install pandas numpy matplotlib scikit-learn statsmodels
2. Open the notebook in Jupyter or Google Colab.
3. Keep retail_price.csv in the same working directory as the notebook.
4. Run cells from top to bottom.

Validation notes (2026-10-22):
- All code cells pass Python syntax compilation.
- The Q-learning section was executed separately on retail_price.csv and completed successfully: 537 training rows, 141 chronological test rows, 10,000 episodes, 64 discrete states, and four pricing strategies evaluated on the same 141 test contexts.
- The full notebook did not finish within the validation time limit, due to runtime in earlier existing sections; therefore it is not certified as fully end-to-end validated.
- Simulated profit is model-based, not observed real-world profit. Unit cost is assumed from training-period median product price; the dataset does not include verified inventory-on-hand or lead-time data.
